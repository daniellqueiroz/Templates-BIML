﻿CREATE SCHEMA [Sales]
    AUTHORIZATION [dbo];

