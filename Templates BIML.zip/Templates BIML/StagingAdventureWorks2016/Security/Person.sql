﻿CREATE SCHEMA [Person]
    AUTHORIZATION [dbo];

