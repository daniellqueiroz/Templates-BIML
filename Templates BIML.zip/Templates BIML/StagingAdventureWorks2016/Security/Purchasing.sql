﻿CREATE SCHEMA [Purchasing]
    AUTHORIZATION [dbo];

